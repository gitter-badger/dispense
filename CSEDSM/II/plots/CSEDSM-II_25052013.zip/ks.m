fc=1;
L=32;
R=0.999;
step=0.01;
W=[0:step:2*pi-step];
z=exp(i*W);
H=(0.5*(1+z.^(-1)))./(1-(R^L*z.^(-L).*0.5.*(1+z.^(-1))));
plot(W,20*log10(abs(H)))
axis([0 pi -40 25])