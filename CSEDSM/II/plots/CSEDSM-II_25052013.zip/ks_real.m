fc=44100;
sinc=1/fc;
dur=20;
T=[0:sinc:dur-sinc];
X=zeros(length(T),1);
Y=zeros(length(X),1);
freq=65;
attack=5;
L=round((fc/freq)-0.5)
X(1000+L:1000+L+attack-1)=rand(attack,1)*2-1;
R=0.99999;
for k=L+10:length(X)
    Y(k)=X(k)-(((R^L)*0.5).*(Y(k-L)+Y(k-L-1)));
end
wavwrite(Y, fc, 16, "ks_out.wav");